import fs from "node:fs/promises";
import path from "node:path";
import ts from "typescript";
import {
  cradleTypeImportUsesDefaultExport,
  resolveContractTypeSourceFile,
} from "./contractTypeSourceFile.js";
import type { DiscoveredFactory } from "./types.js";
import type { ResolvedContractRegistration } from "./resolveRegistrationPlan.js";
import type {
  IocContractManifest,
  IocGroupNodeManifest,
  IocGroupsManifest,
  ModuleFactoryManifestMetadata,
} from "../core/manifest.js";

export type IocRegistryTypesBuildContext = {
  program: ts.Program;
  generatedDir: string;
};

export type WriteManifestOptions = {
  registryTypesBuildContext?: IocRegistryTypesBuildContext;
};

/** Deterministic ordering for manifest output. */
const sortFactoriesForManifest = (
  factories: DiscoveredFactory[],
): DiscoveredFactory[] =>
  [...factories].sort((a, b) => {
    if (a.registrationKey !== b.registrationKey) {
      return a.registrationKey.localeCompare(b.registrationKey);
    }
    if (a.modulePath !== b.modulePath) {
      return a.modulePath.localeCompare(b.modulePath);
    }
    return a.exportName.localeCompare(b.exportName);
  });

/** One row per implementation module, in stable order. */
const uniqueModuleRows = (
  sortedFactories: DiscoveredFactory[],
): { relImport: string; modulePath: string }[] => {
  const seen = new Map<string, { relImport: string; modulePath: string }>();

  for (const factory of sortedFactories) {
    if (seen.has(factory.modulePath)) {
      continue;
    }

    seen.set(factory.modulePath, {
      relImport: factory.relImport,
      modulePath: factory.modulePath,
    });
  }

  return Array.from(seen.values()).sort((a, b) =>
    a.modulePath.localeCompare(b.modulePath),
  );
};

const sanitizeToIdentifierPart = (raw: string): string => {
  const s = raw.replace(/[^a-zA-Z0-9_]/g, "_");
  if (s.length === 0) {
    return "module";
  }
  if (/^[0-9]/.test(s)) {
    return `_${s}`;
  }
  return s;
};

const tsIdentifierOrQuoted = (key: string): string =>
  /^[a-zA-Z_$][\w$]*$/.test(key) ? key : JSON.stringify(key);

/**
 * Stable, collision-safe namespace identifiers derived from module paths
 * (e.g. `examples/a-single-implementation.ts` → `ioc_examples_a_single_implementation`).
 */
const assignStableModuleAliases = (
  modules: { relImport: string; modulePath: string }[],
): Map<string, string> => {
  const pathToAlias = new Map<string, string>();
  const used = new Set<string>();

  for (const moduleEntry of modules) {
    const withoutExt = moduleEntry.modulePath.replace(/\.[^.]+$/, "");
    const segments = withoutExt.split(/[/\\]/).filter(Boolean);
    const base = sanitizeToIdentifierPart(
      segments.length > 0 ? `ioc_${segments.join("_")}` : "ioc_module",
    );

    let candidate = base;
    let n = 2;
    while (used.has(candidate)) {
      candidate = `${base}_${n}`;
      n += 1;
    }

    used.add(candidate);
    pathToAlias.set(moduleEntry.modulePath, candidate);
  }

  return pathToAlias;
};

const buildModuleIndexByPath = (
  modules: { relImport: string; modulePath: string }[],
): Map<string, number> => {
  const out = new Map<string, number>();

  modules.forEach((row, index) => {
    out.set(row.modulePath, index);
  });

  return out;
};

const plansToIocContractManifest = (
  plans: ResolvedContractRegistration[],
  moduleIndexByPath: Map<string, number>,
): IocContractManifest => {
  const out: IocContractManifest = {};

  for (const plan of plans) {
    const implementations: Record<string, ModuleFactoryManifestMetadata> = {};

    for (const impl of plan.implementations) {
      const moduleIndex = moduleIndexByPath.get(impl.modulePath);
      if (moduleIndex === undefined) {
        throw new Error(
          `[ioc] internal error: module path "${impl.modulePath}" missing from module index map`,
        );
      }

      const isResolvedDefault =
        impl.implementationName === plan.defaultImplementationName;
      const accessKeyDiffersFromConvention =
        plan.accessKey !== plan.contractKey;

      implementations[impl.implementationName] = {
        exportName: impl.exportName,
        registrationKey: impl.registrationKey,
        modulePath: impl.modulePath,
        relImport: impl.relImport,
        contractName: plan.contractName,
        implementationName: impl.implementationName,
        lifetime: impl.lifetime,
        moduleIndex,
        ...(isResolvedDefault ? { default: true } : {}),
        ...(accessKeyDiffersFromConvention
          ? { accessKey: plan.accessKey }
          : {}),
        ...(impl.discoveredBy !== undefined
          ? { discoveredBy: impl.discoveredBy }
          : {}),
        ...(impl.configOverridesApplied !== undefined &&
        impl.configOverridesApplied.length > 0
          ? { configOverridesApplied: impl.configOverridesApplied }
          : {}),
        ...(impl.dependencyContractNames !== undefined &&
        impl.dependencyContractNames.length > 0
          ? { dependencyContractNames: impl.dependencyContractNames }
          : {}),
      };
    }

    out[plan.contractName] = implementations;
  }

  return out;
};

const serializeGroupNodeLiteral = (
  node: IocGroupNodeManifest,
  baseIndent: string,
): string => {
  const inner = `${baseIndent}  `;

  if (Array.isArray(node)) {
    if (node.length === 0) {
      return "[]";
    }

    const lines: string[] = ["["];
    for (const leaf of node) {
      lines.push(`${inner}{`);
      lines.push(
        `${inner}  contractName: ${JSON.stringify(leaf.contractName)},`,
      );
      lines.push(
        `${inner}  registrationKey: ${JSON.stringify(leaf.registrationKey)},`,
      );
      lines.push(`${inner}},`);
    }
    lines.push(`${baseIndent}]`);
    return lines.join("\n");
  }

  const propKeys = Object.keys(node).sort((a, b) => a.localeCompare(b));
  if (propKeys.length === 0) {
    return "{}";
  }

  const lines: string[] = ["{"];
  for (const propKey of propKeys) {
    const leaf = node[propKey]!;
    lines.push(`${inner}${tsIdentifierOrQuoted(propKey)}: {`);
    lines.push(`${inner}  contractName: ${JSON.stringify(leaf.contractName)},`);
    lines.push(
      `${inner}  registrationKey: ${JSON.stringify(leaf.registrationKey)},`,
    );
    lines.push(`${inner}},`);
  }
  lines.push(`${baseIndent}}`);
  return lines.join("\n");
};

const serializeGroupRootsForManifest = (
  groupsManifest: IocGroupsManifest | undefined,
): string => {
  if (groupsManifest === undefined) {
    return "";
  }

  const rootKeys = Object.keys(groupsManifest).sort((a, b) =>
    a.localeCompare(b),
  );
  const blocks: string[] = [];

  for (const key of rootKeys) {
    const node = groupsManifest[key]!;
    blocks.push("");
    blocks.push(`  // ${key}`);
    blocks.push(
      `  ${tsIdentifierOrQuoted(key)}: ${serializeGroupNodeLiteral(node, "  ")},`,
    );
  }

  return blocks.join("\n");
};

const buildIocManifestGroupRootsTypeSource = (
  groupsManifest: IocGroupsManifest,
): string => {
  const rootKeys = Object.keys(groupsManifest).sort((a, b) =>
    a.localeCompare(b),
  );
  const lines: string[] = ["type IocManifestGroupRoots = {"];

  for (const key of rootKeys) {
    const node = groupsManifest[key]!;
    if (Array.isArray(node)) {
      lines.push(`  readonly ${tsIdentifierOrQuoted(key)}: readonly [`);
      for (const leaf of node) {
        lines.push(
          `    { readonly contractName: ${JSON.stringify(leaf.contractName)}; readonly registrationKey: ${JSON.stringify(leaf.registrationKey)} },`,
        );
      }
      lines.push("  ];");
      continue;
    }

    lines.push(`  readonly ${tsIdentifierOrQuoted(key)}: {`);
    const propKeys = Object.keys(node).sort((a, b) => a.localeCompare(b));
    for (const propKey of propKeys) {
      const leaf = node[propKey]!;
      lines.push(
        `    readonly ${tsIdentifierOrQuoted(propKey)}: { readonly contractName: ${JSON.stringify(leaf.contractName)}; readonly registrationKey: ${JSON.stringify(leaf.registrationKey)} };`,
      );
    }
    lines.push("  };");
  }

  lines.push("};");
  return lines.join("\n");
};

const serializeMetadataBlock = (
  meta: ModuleFactoryManifestMetadata,
): string => {
  const lines = [
    `      exportName: ${JSON.stringify(meta.exportName)},`,
    `      registrationKey: ${JSON.stringify(meta.registrationKey)},`,
    `      modulePath: ${JSON.stringify(meta.modulePath)},`,
    `      relImport: ${JSON.stringify(meta.relImport)},`,
    `      contractName: ${JSON.stringify(meta.contractName)},`,
    `      implementationName: ${JSON.stringify(meta.implementationName)},`,
    `      lifetime: ${JSON.stringify(meta.lifetime)},`,
    `      moduleIndex: ${meta.moduleIndex},`,
  ];

  if (meta.group !== undefined) {
    lines.push(`      group: ${JSON.stringify(meta.group)},`);
  }
  if (meta.default !== undefined) {
    lines.push(`      default: ${meta.default},`);
  }
  if (meta.discoveredBy !== undefined) {
    lines.push(`      discoveredBy: ${JSON.stringify(meta.discoveredBy)},`);
  }
  if (meta.configOverridesApplied !== undefined) {
    lines.push(
      `      configOverridesApplied: ${JSON.stringify(meta.configOverridesApplied)},`,
    );
  }
  if (meta.dependencyContractNames !== undefined) {
    lines.push(
      `      dependencyContractNames: ${JSON.stringify(meta.dependencyContractNames)},`,
    );
  }
  if (meta.accessKey !== undefined) {
    lines.push(`      accessKey: ${JSON.stringify(meta.accessKey)},`);
  }

  return lines.join("\n");
};

const serializeRegistrationManifestValue = (
  manifest: IocContractManifest,
): string => {
  const contractNames = Object.keys(manifest).sort((a, b) =>
    a.localeCompare(b),
  );
  const contractLines: string[] = ["{"];

  for (const contractName of contractNames) {
    const impls = manifest[contractName]!;
    const implKeys = Object.keys(impls).sort((a, b) => a.localeCompare(b));

    contractLines.push(`  ${JSON.stringify(contractName)}: {`);
    for (const implKey of implKeys) {
      const meta = impls[implKey]!;
      contractLines.push(`    ${JSON.stringify(implKey)}: {`);
      contractLines.push(serializeMetadataBlock(meta));
      contractLines.push("    },");
    }
    contractLines.push("  },");
  }

  contractLines.push("}");
  return contractLines.join("\n");
};

const serializeMainIocManifestSource = (
  contractManifest: IocContractManifest,
  groupsManifest: IocGroupsManifest | undefined,
  manifestImportFromPackage: string,
  importLines: string[],
  moduleArrayLines: string[],
): string => {
  const header = `/* AUTO-GENERATED. DO NOT EDIT.
Primary container manifest.
Re-run \`npm run gen:manifest\` after changing factories or IoC config.
*/
`;

  const groupRootsBlock = serializeGroupRootsForManifest(groupsManifest);
  const hasGroups =
    groupsManifest !== undefined && Object.keys(groupsManifest).length > 0;
  const groupRootsTypeBlock = hasGroups
    ? `${buildIocManifestGroupRootsTypeSource(groupsManifest)}\n\n`
    : "";
  const satisfiesType = hasGroups
    ? "IocGeneratedContainerManifest<IocManifestGroupRoots>"
    : "IocGeneratedContainerManifest";
  const contractsBlock = serializeRegistrationManifestValue(contractManifest);

  return `${header}import type {
  IocGeneratedContainerManifest,
  IocModuleNamespace,
} from "${manifestImportFromPackage}";

${importLines.join("\n")}

${groupRootsTypeBlock}export const iocManifest = {
  moduleImports: [
${moduleArrayLines.join("\n")}
  ] as const satisfies readonly IocModuleNamespace[],

  contracts: ${contractsBlock},${groupRootsBlock}
} as const satisfies ${satisfiesType};
`;
};

const buildCradleTypeSource = (
  plans: ResolvedContractRegistration[],
  groupsManifest: IocGroupsManifest | undefined,
  registryTypesBuildContext?: IocRegistryTypesBuildContext,
): string => {
  const importLines: string[] = [];

  if (registryTypesBuildContext === undefined) {
    const typeImports = new Map<string, Set<string>>();

    for (const plan of plans) {
      const importPath = plan.contractTypeRelImport;
      const set = typeImports.get(importPath) ?? new Set<string>();
      set.add(plan.contractName);
      typeImports.set(importPath, set);
    }

    for (const [relImport, names] of Array.from(typeImports.entries()).sort(
      ([a], [b]) => a.localeCompare(b),
    )) {
      const sorted = Array.from(names).sort((x, y) => x.localeCompare(y));
      importLines.push(
        `import type { ${sorted.join(", ")} } from "${relImport}";`,
      );
    }
  } else {
    const { program, generatedDir } = registryTypesBuildContext;
    const grouped = new Map<
      string,
      { named: Set<string>; defaults: Set<string> }
    >();

    for (const plan of plans) {
      const relImport = plan.contractTypeRelImport;
      let bucket = grouped.get(relImport);
      if (bucket === undefined) {
        bucket = { named: new Set(), defaults: new Set() };
        grouped.set(relImport, bucket);
      }

      const sourceFile = resolveContractTypeSourceFile(
        program,
        generatedDir,
        relImport,
      );
      const useDefault =
        sourceFile !== undefined &&
        cradleTypeImportUsesDefaultExport(sourceFile, plan.contractName);

      if (useDefault) {
        bucket.defaults.add(plan.contractName);
      } else {
        bucket.named.add(plan.contractName);
      }
    }

    for (const [relImport, bucket] of Array.from(grouped.entries()).sort(
      ([a], [b]) => a.localeCompare(b),
    )) {
      const defaultNames = Array.from(bucket.defaults).sort((x, y) =>
        x.localeCompare(y),
      );
      const namedNames = Array.from(bucket.named).sort((x, y) =>
        x.localeCompare(y),
      );

      for (const defaultName of defaultNames) {
        importLines.push(`import type ${defaultName} from "${relImport}";`);
      }
      if (namedNames.length > 0) {
        importLines.push(
          `import type { ${namedNames.join(", ")} } from "${relImport}";`,
        );
      }
    }
  }

  const propertyLines: string[] = [];
  const sortedPlans = [...plans].sort((a, b) =>
    a.contractName.localeCompare(b.contractName),
  );

  for (const plan of sortedPlans) {
    const typeName = plan.contractName;
    propertyLines.push(`  ${plan.accessKey}: ${typeName};`);

    if (plan.collectionKey !== undefined) {
      propertyLines.push(
        `  ${plan.collectionKey}: ReadonlyArray<${typeName}>;`,
      );
    }
  }

  const appendGroupNodeType = (
    node: IocGroupNodeManifest,
    indent: string,
  ): string => {
    if (Array.isArray(node)) {
      const seen = new Set<string>();
      const order: string[] = [];

      for (const leaf of node) {
        if (!seen.has(leaf.contractName)) {
          seen.add(leaf.contractName);
          order.push(leaf.contractName);
        }
      }

      const union = order.length > 0 ? order.join(" | ") : "never";
      return `ReadonlyArray<${union}>`;
    }

    const lines: string[] = [`${indent}{`];
    const sortedKeys = Object.keys(node).sort((a, b) => a.localeCompare(b));

    for (const key of sortedKeys) {
      const leaf = node[key]!;
      lines.push(
        `${indent}  ${tsIdentifierOrQuoted(key)}: ${leaf.contractName};`,
      );
    }

    lines.push(`${indent}}`);
    return lines.join("\n");
  };

  if (groupsManifest !== undefined) {
    const groupRootKeys = Object.keys(groupsManifest).sort((a, b) =>
      a.localeCompare(b),
    );

    for (const key of groupRootKeys) {
      const node = groupsManifest[key]!;
      propertyLines.push(
        `  ${tsIdentifierOrQuoted(key)}: ${appendGroupNodeType(node, "")};`,
      );
    }
  }

  const header = `/* AUTO-GENERATED. DO NOT EDIT.
Re-run \`npm run gen:manifest\` after changing factories or IoC config.
*/
`;

  return `${header}${importLines.length > 0 ? importLines.join("\n") + "\n\n" : ""}export interface IocGeneratedTypes {
${propertyLines.join("\n")}
}

export type IocGeneratedCradle = IocGeneratedTypes;
`;
};

const replaceFileFromTemp = async (
  targetPath: string,
  contents: string,
): Promise<void> => {
  const tempPath = `${targetPath}.tmp-${process.pid}-${Date.now()}`;

  try {
    await fs.writeFile(tempPath, contents, "utf8");
    await fs.rename(tempPath, targetPath);
  } catch (error) {
    try {
      await fs.unlink(tempPath);
    } catch {
      // Best effort cleanup; keep original failure context.
    }
    throw error;
  }
};

export const writeManifest = async (
  acceptedFactories: DiscoveredFactory[],
  plans: ResolvedContractRegistration[],
  groupsManifest: IocGroupsManifest | undefined,
  manifestOutPath: string,
  manifestImportFromPackage: string,
  options?: WriteManifestOptions,
): Promise<void> => {
  const sortedFactories = sortFactoriesForManifest(acceptedFactories);
  const modules = uniqueModuleRows(sortedFactories);
  const moduleIndexByPath = buildModuleIndexByPath(modules);
  const aliasByPath = assignStableModuleAliases(modules);
  const contractManifest = plansToIocContractManifest(plans, moduleIndexByPath);
  const iocGroupsManifest: IocGroupsManifest | undefined = groupsManifest;

  const importLines = modules.map((moduleEntry) => {
    const alias = aliasByPath.get(moduleEntry.modulePath);
    if (!alias) {
      throw new Error(
        `[ioc] internal error: missing alias for "${moduleEntry.modulePath}"`,
      );
    }
    return `import * as ${alias} from "${moduleEntry.relImport}";`;
  });

  const moduleArrayLines = modules.map((moduleEntry) => {
    const alias = aliasByPath.get(moduleEntry.modulePath);
    if (!alias) {
      throw new Error(
        `[ioc] internal error: missing alias for "${moduleEntry.modulePath}"`,
      );
    }
    return `  ${alias},`;
  });

  const mainSource = serializeMainIocManifestSource(
    contractManifest,
    iocGroupsManifest,
    manifestImportFromPackage,
    importLines,
    moduleArrayLines,
  );

  await replaceFileFromTemp(manifestOutPath, mainSource);

  const typesPath = path.join(
    path.dirname(manifestOutPath),
    "ioc-registry.types.ts",
  );
  const typesSource = buildCradleTypeSource(
    plans,
    iocGroupsManifest,
    options?.registryTypesBuildContext,
  );
  await replaceFileFromTemp(typesPath, typesSource);
};
