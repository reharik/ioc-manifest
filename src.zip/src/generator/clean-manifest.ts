import fs from "node:fs/promises";
import path from "node:path";
import {
  tryLoadIocConfig,
  resolveIocConfigPath,
} from "../config/loadIocConfig.js";
import {
  mergeManifestOptionsWithIocConfig,
  resolveManifestOptions,
} from "./manifestOptions.js";

const getCoreManifestImportSpecifier = (
  manifestOutPath: string,
  projectRoot: string,
): string => {
  const manifestDir = path.dirname(manifestOutPath);
  const coreDir = path.join(projectRoot, "src", "core");
  let rel = path.relative(manifestDir, coreDir).replace(/\\/g, "/");
  if (!rel.startsWith(".")) {
    rel = `./${rel}`;
  }
  return `${rel}/manifest.js`;
};

const TYPES_STUB = `/* AUTO-GENERATED STUB.
This fallback exists so the project can compile even when IoC generation fails.
The real generator should overwrite this file on success.
*/

export type IocGeneratedCradle = Record<string, unknown>;
`;

const run = async (): Promise<void> => {
  const base = resolveManifestOptions();
  const configPath = resolveIocConfigPath(base.paths.projectRoot);
  const config = await tryLoadIocConfig(configPath);
  const options = config
    ? mergeManifestOptionsWithIocConfig(base, config)
    : base;

  const { manifestOutPath, generatedDir, projectRoot } = options.paths;
  const typesPath = path.join(generatedDir, "ioc-registry.types.ts");

  const manifestStub = `/* AUTO-GENERATED. DO NOT EDIT. */

import type { IocContractManifest } from "${getCoreManifestImportSpecifier(manifestOutPath, projectRoot)}";

export const iocModuleImports = [] as const;

export const iocManifestByContract: IocContractManifest = {};
`;

  await fs.mkdir(generatedDir, { recursive: true });
  await fs.writeFile(manifestOutPath, manifestStub, "utf8");
  let typesFileExists = true;
  try {
    await fs.access(typesPath);
  } catch {
    typesFileExists = false;
  }
  if (!typesFileExists) {
    await fs.writeFile(typesPath, TYPES_STUB, "utf8");
  }
  console.log(
    "[clean-manifest] Reset manifest stub at",
    manifestOutPath,
    typesFileExists
      ? "and preserved existing registry types at"
      : "and created registry types stub at",
    typesPath,
  );
};

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
