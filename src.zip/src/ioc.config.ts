import { defineIocConfig } from "./config/iocConfig.js";

export default defineIocConfig({
  discovery: {
    rootDir: "src",
    includes: ["examples2/**/*.{ts,tsx,js,mjs,cjs}"],
    excludes: [
      "**/*.d.ts",
      "**/*.test.{ts,tsx,js,mjs,cjs}",
      "examples2/e-invalid-*.ts",
      "generated/**/*",
      "dist/**/*",
      "node_modules/**/*",
      "examples3/**/*",
    ],
    factoryPrefix: "build",
  },
  registrations: {
    Widget: {
      primaryWidget: { default: true },
    },
    MediaStorage: {
      s3MediaStorage: { default: true },
    },
    Logger: {
      consoleLogger: { default: true },
    },
  },
});
