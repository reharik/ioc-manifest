/* AUTO-GENERATED. DO NOT EDIT.
Re-run `npm run gen:manifest` after changing factories or IoC config.
*/
import type { Logger } from "../examples2/a-single-implementation.js";
import type { MediaStorage } from "../examples2/b-multiple-implementations.js";
import type { Widget } from "../examples2/c-default-selection.js";
import type { CacheClient } from "../examples2/d-grouping.js";
import type { AlbumService } from "../examples2/f-dependency-injection.js";

export interface IocGeneratedCradle {
  albumService: AlbumService;
  cacheClient: CacheClient;
  memoryCache: CacheClient;
  logger: Logger;
  consoleLogger: Logger;
  mediaStorage: MediaStorage;
  localMediaStorage: MediaStorage;
  s3MediaStorage: MediaStorage;
  mediaStorages: Record<
    "localMediaStorage" | "mediaStorage" | "s3MediaStorage",
    MediaStorage
  >;
  widget: Widget;
  primaryWidget: Widget;
  secondaryWidget: Widget;
  widgets: Record<"primaryWidget" | "secondaryWidget", Widget>;
}
