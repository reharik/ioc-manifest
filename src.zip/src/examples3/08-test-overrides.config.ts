import { defineIocConfig } from "../config/iocConfig";

export default defineIocConfig({
  discovery: {
    rootDir: "src",
    includes: ["examples3/**/*.ts"],
    excludes: ["examples3/90-invalid-*.ts"],
    factoryPrefix: "build",
  },
  registrations: {
    MediaStorage: {
      mockMediaStorage: {
        default: true,
        lifetime: "singleton",
      },
    },
    CacheClient: {
      redisCache: {
        default: true,
      },
    },
  },
});
