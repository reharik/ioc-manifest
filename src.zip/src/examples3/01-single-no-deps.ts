import { injectable } from "../core";
import type { Logger } from "./00-contracts";

export const buildConsoleLogger = injectable(
  (): Logger => ({
    info(message: string) {
      console.log("[console]", message);
    },
  }),
);
