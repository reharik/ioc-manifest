import type { Widget } from "./00-contracts";

export const buildPrimaryWidget = (): Widget => ({ id: "primary" });

export const buildSecondaryWidget = (): Widget => ({ id: "secondary" });
