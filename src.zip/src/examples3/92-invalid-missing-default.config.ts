import { defineIocConfig } from "../config/iocConfig";

export default defineIocConfig({
  discovery: {
    rootDir: "src",
    includes: ["examples3/**/*.ts"],
    factoryPrefix: "build",
  },
  registrations: {
    Strategy: {
      notARealStrategy: {
        default: true,
      },
    },
  },
});
