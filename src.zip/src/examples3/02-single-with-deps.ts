import { injectable } from "../core";
import { IocGeneratedCradle } from "../generated/ioc-registry.types";
import type { CacheClient, Logger, ReportService } from "./00-contracts";

export type BuildReportServiceDeps = {
  cacheClient: CacheClient;
  logger: Logger;
};

export const buildReportService = injectable(
  ({ cacheClient, logger }: IocGeneratedCradle): ReportService => ({
    async buildReport(id: string) {
      logger.info(`building report:${id}`);
      const cached = await cacheClient.get(id);
      if (cached) return cached;
      const report = `report:${id}`;
      await cacheClient.set(id, report);
      return report;
    },
  }),
);
