import type { MediaStorage } from "./00-contracts";

export const buildMediaStorage = (): MediaStorage => ({
  async put(key: string) {
    return `collision://${key}`;
  },
});
