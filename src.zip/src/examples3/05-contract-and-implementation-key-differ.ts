import { injectable } from "../core";
import type { CacheClient } from "./00-contracts";

export const buildPreferredCache = injectable(
  (): CacheClient => ({
    async get(key: string) {
      return `preferred:${key}`;
    },
    async set() {},
  }),
);
