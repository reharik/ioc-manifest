import { injectable } from "../core";
import type { CacheClient, MediaStorage } from "./00-contracts";

const memory = new Map<string, string>();

export const buildMemoryCache = injectable(
  (): CacheClient => ({
    async get(key: string) {
      return memory.get(key);
    },
    async set(key: string, value: string) {
      memory.set(key, value);
    },
  }),
);

export const buildRedisCache = injectable(
  (): CacheClient => ({
    async get(key: string) {
      return `redis:${key}`;
    },
    async set() {},
  }),
);

export const buildLocalMediaStorage = injectable(
  (): MediaStorage => ({
    async put(key: string) {
      return `file:///tmp/${key}`;
    },
  }),
);

export const buildS3MediaStorage = injectable(
  (): MediaStorage => ({
    async put(key: string) {
      return `s3://bucket/${key}`;
    },
  }),
);

export const buildMockMediaStorage = injectable(
  (): MediaStorage => ({
    async put(key: string) {
      return `mock://${key}`;
    },
  }),
);
