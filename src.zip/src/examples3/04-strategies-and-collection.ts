import { injectable } from "../core/injectable";
import { IocGeneratedCradle } from "../generated/ioc-registry.types";
import type { Strategy, StrategyRunner } from "./00-contracts";

export const buildUppercaseStrategy = injectable(
  (): Strategy => ({
    name: "uppercase",
    supports(kind: string) {
      return kind === "upper";
    },
    execute(input: string) {
      return input.toUpperCase();
    },
  }),
);

export const buildReverseStrategy = injectable(
  (): Strategy => ({
    name: "reverse",
    supports(kind: string) {
      return kind === "reverse";
    },
    execute(input: string) {
      return input.split("").reverse().join("");
    },
  }),
);

export const buildEchoStrategy = injectable(
  (): Strategy => ({
    name: "echo",
    supports(kind: string) {
      return kind === "echo";
    },
    execute(input: string) {
      return input;
    },
  }),
);

export const buildStrategyRunner = injectable(
  ({ strategies }: IocGeneratedCradle): StrategyRunner => ({
    run(kind: string, input: string) {
      const strategy = Object.values(strategies).find((candidate) =>
        candidate.supports(kind),
      );
      if (!strategy) {
        throw new Error(`No strategy for kind: ${kind}`);
      }
      return strategy.execute(input);
    },
  }),
);
