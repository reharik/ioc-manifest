import { injectable } from "../core";
import { IocGeneratedCradle } from "../generated/ioc-registry.types";

export interface UploadReporter {
  saveAndReport(key: string, data: Uint8Array): Promise<string>;
}

export const buildUploadReporter = injectable(
  ({
    logger,
    mediaStorage,
    reportService,
  }: IocGeneratedCradle): UploadReporter => ({
    async saveAndReport(key: string, data: Uint8Array) {
      logger.info(`saving:${key}`);
      const location = await mediaStorage.put(key, data);
      const report = await reportService.buildReport(key);
      return `${location}|${report}`;
    },
  }),
);
