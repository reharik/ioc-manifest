export interface Logger {
  info(message: string): void;
}

export interface CacheClient {
  get(key: string): Promise<string | undefined>;
  set(key: string, value: string): Promise<void>;
}

export interface MediaStorage {
  put(key: string, data: Uint8Array): Promise<string>;
}

export interface Widget {
  id: string;
}

export interface Strategy {
  name: string;
  supports(kind: string): boolean;
  execute(input: string): string;
}

export interface StrategyRunner {
  run(kind: string, input: string): string;
}

export interface ReportService {
  buildReport(id: string): Promise<string>;
}
