import { defineIocConfig } from "../config/iocConfig";

export default defineIocConfig({
  discovery: {
    rootDir: "src",
    includes: ["examples3/**/*.ts"],
    excludes: ["examples3/90-invalid-*.ts", "examples3/91-invalid-*.ts"],
    factoryPrefix: "build",
  },
  registrations: {
    CacheClient: {
      memoryCache: {
        default: true,
        lifetime: "singleton",
      },
      preferredCache: {
        name: "blah",
      },
    },
    MediaStorage: {
      s3MediaStorage: {
        default: true,
        lifetime: "scoped",
      },
    },
    Strategy: {
      reverseStrategy: {
        default: true,
      },
    },
  },
});
