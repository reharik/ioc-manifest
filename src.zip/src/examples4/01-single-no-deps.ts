import type { Logger } from "./00-contracts";

export const buildConsoleLogger = (): Logger => ({
  info(message: string) {
    console.log("[console]", message);
  },
});
