import type { CacheClient, Logger, ReportService } from "./00-contracts";

export type BuildReportServiceDeps = {
  cacheClient: CacheClient;
  logger: Logger;
};

export const buildReportService = ({
  cacheClient,
  logger,
}: BuildReportServiceDeps): ReportService => ({
  async buildReport(id: string) {
    logger.info(`building report:${id}`);
    const cached = await cacheClient.get(id);
    if (cached) return cached;
    const report = `report:${id}`;
    await cacheClient.set(id, report);
    return report;
  },
});
