import type { Logger, MediaStorage, ReportService } from "./00-contracts";

export type BuildUploadReporterDeps = {
  logger: Logger;
  mediaStorage: MediaStorage;
  reportService: ReportService;
};

export interface UploadReporter {
  saveAndReport(key: string, data: Uint8Array): Promise<string>;
}

export const buildUploadReporter = ({
  logger,
  mediaStorage,
  reportService,
}: BuildUploadReporterDeps): UploadReporter => ({
  async saveAndReport(key: string, data: Uint8Array) {
    logger.info(`saving:${key}`);
    const location = await mediaStorage.put(key, data);
    const report = await reportService.buildReport(key);
    return `${location}|${report}`;
  },
});
