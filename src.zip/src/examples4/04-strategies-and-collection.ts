import type { Strategy, StrategyRunner } from "./00-contracts";

export const buildUppercaseStrategy = (): Strategy => ({
  name: "uppercase",
  supports(kind: string) {
    return kind === "upper";
  },
  execute(input: string) {
    return input.toUpperCase();
  },
});

export const buildReverseStrategy = (): Strategy => ({
  name: "reverse",
  supports(kind: string) {
    return kind === "reverse";
  },
  execute(input: string) {
    return input.split("").reverse().join("");
  },
});

export const buildEchoStrategy = (): Strategy => ({
  name: "echo",
  supports(kind: string) {
    return kind === "echo";
  },
  execute(input: string) {
    return input;
  },
});

export type BuildStrategyRunnerDeps = {
  strategies: Record<string, Strategy>;
};

export const buildStrategyRunner = ({
  strategies,
}: BuildStrategyRunnerDeps): StrategyRunner => ({
  run(kind: string, input: string) {
    const strategy = Object.values(strategies).find((candidate) =>
      candidate.supports(kind),
    );
    if (!strategy) {
      throw new Error(`No strategy for kind: ${kind}`);
    }
    return strategy.execute(input);
  },
});
