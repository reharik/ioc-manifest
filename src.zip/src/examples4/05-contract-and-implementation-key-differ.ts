import type { CacheClient } from "./00-contracts";

export const buildPreferredCache = (): CacheClient => ({
  async get(key: string) {
    return `preferred:${key}`;
  },
  async set() {},
});
