import type { CacheClient, MediaStorage } from "./00-contracts";

const memory = new Map<string, string>();

export const buildMemoryCache = (): CacheClient => ({
  async get(key: string) {
    return memory.get(key);
  },
  async set(key: string, value: string) {
    memory.set(key, value);
  },
});

export const buildRedisCache = (): CacheClient => ({
  async get(key: string) {
    return `redis:${key}`;
  },
  async set() {},
});

export const buildLocalMediaStorage = (): MediaStorage => ({
  async put(key: string) {
    return `file:///tmp/${key}`;
  },
});

export const buildS3MediaStorage = (): MediaStorage => ({
  async put(key: string) {
    return `s3://bucket/${key}`;
  },
});

export const buildMockMediaStorage = (): MediaStorage => ({
  async put(key: string) {
    return `mock://${key}`;
  },
});
