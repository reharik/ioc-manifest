import { defineIocConfig } from "../config/iocConfig";

export default defineIocConfig({
  discovery: {
    rootDir: "src",
    includes: ["examples4/**/*.ts"],
    excludes: ["examples4/90-invalid-*.ts", "examples4/91-invalid-*.ts"],
    factoryPrefix: "build",
  },
  registrations: {
    CacheClient: {
      memoryCache: {
        default: true,
        lifetime: "singleton",
      },
    },
    MediaStorage: {
      localMediaStorage: {
        default: true,
        lifetime: "scoped",
      },
    },
    Strategy: {
      reverseStrategy: {
        default: true,
      },
    },
  },
});
