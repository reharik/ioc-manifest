import assert from "node:assert";
import { describe, it } from "node:test";
import { createContainer } from "awilix";
import type { CacheClient, MediaStorage } from "../examples3/00-contracts.js";
import type { IocGeneratedCradle } from "../generated/ioc-registry.types.js";
import { iocManifestByContract, iocModuleImports } from "../generated/ioc-manifest.js";
import { registerIocFromManifest } from "./bootstrap.js";

describe("registerIocFromManifest", () => {
  describe("When resolving the contract default slot", () => {
    it("should resolve to the selected default implementation", async () => {
      const container = createContainer<IocGeneratedCradle>();
      registerIocFromManifest(container, iocManifestByContract, iocModuleImports);
      const media = container.resolve("mediaStorage") as MediaStorage;
      assert.strictEqual(
        await media.put("k", new Uint8Array()),
        "s3://bucket/k",
      );
    });
  });

  describe("When resolving named implementation registrations", () => {
    it("should resolve each registration key to its factory", async () => {
      const container = createContainer<IocGeneratedCradle>();
      registerIocFromManifest(container, iocManifestByContract, iocModuleImports);
      const local = container.resolve("localMediaStorage") as MediaStorage;
      assert.strictEqual(
        await local.put("k", new Uint8Array()),
        "file:///tmp/k",
      );
      const preferred = container.resolve("blah") as CacheClient;
      assert.strictEqual(await preferred.get("x"), "preferred:x");
    });
  });

  describe("When resolving the collection key for a multi-implementation contract", () => {
    it("should expose an object map keyed by implementation name", async () => {
      const container = createContainer<IocGeneratedCradle>();
      registerIocFromManifest(container, iocManifestByContract, iocModuleImports);
      const collection = container.resolve("mediaStorages") as Record<
        string,
        MediaStorage
      >;
      assert.ok(collection && typeof collection === "object");
      assert.strictEqual(
        await collection.localMediaStorage.put("k", new Uint8Array()),
        "file:///tmp/k",
      );
      assert.strictEqual(
        await collection.s3MediaStorage.put("k", new Uint8Array()),
        "s3://bucket/k",
      );
    });
  });
});
