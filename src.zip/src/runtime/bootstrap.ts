import {
  aliasTo,
  asFunction,
  Lifetime,
  type AwilixContainer,
  type NameAndRegistrationPair,
} from "awilix";
import type { IocContractManifest, IocModuleNamespace } from "../core/manifest.js";
import {
  contractNameToCollectionRegistrationKey,
  contractNameToDefaultRegistrationKey,
} from "../generator/naming.js";

const lifetimeToAwilix = (
  lifetime: "singleton" | "scoped" | "transient",
): (typeof Lifetime)[keyof typeof Lifetime] => {
  switch (lifetime) {
    case "singleton":
      return Lifetime.SINGLETON;
    case "scoped":
      return Lifetime.SCOPED;
    case "transient":
      return Lifetime.TRANSIENT;
    default: {
      const _exhaustive: never = lifetime;
      return _exhaustive;
    }
  }
};

const registerPair = <TCradle extends object>(
  container: AwilixContainer<TCradle>,
  pair: Record<string, unknown>,
): void => {
  /* Registration keys come from generated manifests; Awilix types cannot express this map statically. */
  container.register(pair as unknown as NameAndRegistrationPair<TCradle>);
};

const isFactoryFunction = (
  value: unknown,
): value is (...args: unknown[]) => unknown => typeof value === "function";

const invokeResolvedFactory = <TCradle extends object>(
  factory: unknown,
  cradle: TCradle,
): unknown => {
  if (!isFactoryFunction(factory)) {
    throw new Error("[ioc] internal error: expected resolver factory function");
  }

  // Natural signatures in examples:
  // - `() => Contract` should be invoked with no args
  // - `(deps) => Contract` should receive the cradle/deps object
  return factory.length === 0 ? factory() : factory(cradle);
};

/**
 * Registers discovered injectable factories from a generated manifest into an Awilix container.
 * Call order: all implementation factories first, then contract default aliases, then collections.
 */
export const registerIocFromManifest = <TCradle extends object>(
  container: AwilixContainer<TCradle>,
  manifestByContract: IocContractManifest,
  moduleImports: readonly IocModuleNamespace[],
): void => {
  for (const impls of Object.values(manifestByContract)) {
    for (const meta of Object.values(impls)) {
      const ns = moduleImports[meta.moduleIndex];
      if (!ns) {
        throw new Error(
          `[ioc] iocModuleImports[${meta.moduleIndex}] is missing (modulePath ${meta.modulePath})`,
        );
      }
      const factory = ns[meta.exportName];
      if (typeof factory !== "function") {
        throw new Error(
          `[ioc] "${meta.modulePath}" has no function export ${JSON.stringify(meta.exportName)} for ${meta.contractName}`,
        );
      }
      registerPair<TCradle>(container, {
        [meta.registrationKey]: asFunction(
          (cradle: TCradle) => invokeResolvedFactory(factory, cradle),
          { lifetime: lifetimeToAwilix(meta.lifetime) },
        ),
      });
    }
  }

  for (const [contractName, impls] of Object.entries(manifestByContract)) {
    const contractKey = contractNameToDefaultRegistrationKey(contractName);
    const implList = Object.values(impls);
    const defaultImpl =
      implList.find((m) => m.default === true) ??
      (implList.length === 1 ? implList[0] : undefined);
    if (!defaultImpl) {
      throw new Error(
        `[ioc] contract ${JSON.stringify(contractName)}: could not determine default implementation (expected exactly one implementation or one row with default: true).`,
      );
    }
    const hasImplementationAtContractKey = implList.some(
      (meta) => meta.registrationKey === contractKey,
    );
    if (
      contractKey !== defaultImpl.registrationKey &&
      !hasImplementationAtContractKey
    ) {
      registerPair<TCradle>(container, {
        [contractKey]: aliasTo(defaultImpl.registrationKey),
      });
    }
  }

  for (const [contractName, impls] of Object.entries(manifestByContract)) {
    const implList = Object.values(impls);
    if (implList.length <= 1) {
      continue;
    }
    const collectionKey = contractNameToCollectionRegistrationKey(contractName);
    registerPair<TCradle>(container, {
      [collectionKey]: asFunction(
        (cradle: TCradle) => {
          const map: Record<string, unknown> = {};
          for (const meta of implList) {
            map[meta.implementationName] =
              cradle[meta.registrationKey as keyof TCradle];
          }
          return map;
        },
        { lifetime: Lifetime.SINGLETON },
      ),
    });
  }
};
