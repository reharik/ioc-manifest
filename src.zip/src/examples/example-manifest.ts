import type { IocManifest } from "../core/manifest.js";
import * as a from "./a-single-implementation.js";
import * as b from "./b-multiple-implementations.js";
import * as c from "./c-default-selection.js";
import * as d from "./d-grouping.js";
import * as e from "./e-invalid-resolvers.js";
import * as f from "./f-dependency-injection.js";

/** Full playground manifest wired manually (no codegen) for `runExample`. */
export const exampleManifest: IocManifest = [
  { modulePath: "examples/a-single-implementation.ts", exports: a },
  { modulePath: "examples/b-multiple-implementations.ts", exports: b },
  { modulePath: "examples/c-default-selection.ts", exports: c },
  { modulePath: "examples/d-grouping.ts", exports: d },
  { modulePath: "examples/e-invalid-resolvers.ts", exports: e },
  { modulePath: "examples/f-dependency-injection.ts", exports: f },
];

/** Media-only slice for demonstrating `defaultOverrides` without a direct `mediaStorage` registration. */
export const mediaOnlyManifest: IocManifest = [
  { modulePath: "examples/b-multiple-implementations.ts", exports: b },
];
