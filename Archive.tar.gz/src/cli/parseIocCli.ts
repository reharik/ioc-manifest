/**
 * @fileoverview Minimal argv parsing for the `ioc` CLI (`inspect` command and `-h/--help`).
 */

/** Printed for `-h`, `--help`, or bare `ioc` — successful exit 0 */
export const IOC_CLI_HELP_TEXT = `ioc — inspect Awilix manifests produced by ioc-manifest

Usage:
  ioc [--help|-h]
  ioc inspect [--discovery] [--config <path> | -c <path>] [--project <path>]
  ioc inspect [--help|-h]

Commands:
  ioc inspect    Load generated ioc-manifest.ts (unless --discovery), print summary.

Options:
  --discovery           Re-run discovery and registration planning; do not read manifest.
  --config PATH   -c    Path to ioc.config.ts
  --project PATH       Directory to resolve config from (default: cwd)

Errors:
  Set IOC_DEBUG=1 for stack traces alongside messages.
`;

const isHelpFlag = (s: string): boolean =>
  s === "--help" || s === "-h";

const conciseUsageTail = (): string =>
  '\nUsage: ioc (--help|-h) | ioc inspect [--discovery] [--config <path>|-c <path>] [--project <path>] | ioc inspect (--help|-h)';

export type IocInspectCliOptions = {
  iocConfigPath?: string;
  projectDir?: string;
  discovery: boolean;
};

export type ParseIocCliArgvResult =
  | { kind: "help" }
  | { kind: "inspect"; options: IocInspectCliOptions };

const cliParseError = (detail: string): Error =>
  new Error(`${detail}${conciseUsageTail()}`);

/**
 * Parses `process.argv`-style arrays (starts with executable and script paths).
 */
export const parseIocCliArgv = (
  argv: readonly string[],
): ParseIocCliArgvResult => {
  const args = argv.slice(2);

  if (args.length === 0 || (args.length === 1 && isHelpFlag(args[0] ?? ""))) {
    return { kind: "help" };
  }

  if (args[0] === "inspect" && args.slice(1).some(isHelpFlag)) {
    return { kind: "help" };
  }

  const command = args[0];
  if (command !== "inspect") {
    throw cliParseError(
      `Unknown command ${JSON.stringify(command)}. Supported: inspect.`,
    );
  }

  let iocConfigPath: string | undefined;
  let projectDir: string | undefined;
  let discovery = false;

  for (let i = 1; i < args.length; i += 1) {
    const a = args[i];
    if (a === undefined) {
      break;
    }
    if (a === "--discovery") {
      discovery = true;
      continue;
    }
    if ((a === "--config" || a === "-c") && args[i + 1]) {
      iocConfigPath = args[i + 1];
      i += 1;
      continue;
    }
    if (a === "--project" && args[i + 1]) {
      projectDir = args[i + 1];
      i += 1;
      continue;
    }
    if (a.startsWith("-")) {
      throw cliParseError(`Unknown flag ${JSON.stringify(a)}.`);
    }
  }

  return {
    kind: "inspect",
    options: {
      ...(iocConfigPath !== undefined ? { iocConfigPath } : {}),
      ...(projectDir !== undefined ? { projectDir } : {}),
      discovery,
    },
  };
};
