#!/usr/bin/env node
/**
 * @fileoverview `ioc` CLI: inspects a **generated** manifest on disk (`iocManifest` export).
 *
 * - `ioc inspect` — human-readable contract / implementation summary + manifest validation.
 * - `ioc inspect --discovery` — re-runs source discovery (no manifest read) for drift analysis.
 *
 * Resolves config like generation (`tryLoadIocConfig`, optional `--config`), walking up from cwd
 * (or `--project`) to find `ioc.config.ts` in a monorepo.
 */
import path from "node:path";
import { pathToFileURL } from "node:url";
import {
  IOC_CLI_HELP_TEXT,
  parseIocCliArgv,
} from "./parseIocCli.js";
import {
  resolveIocConfigPath,
  resolveProjectRootFromIocConfigPath,
  tryLoadIocConfig,
} from "../config/loadIocConfig.js";
import type { IocGeneratedContainerManifest } from "../core/manifest.js";
import {
  mergeManifestOptionsWithIocConfig,
  resolveManifestOptions,
} from "../generator/manifestOptions.js";
import type { ResolvedScanDir } from "../generator/manifestPaths.js";
import {
  buildDiscoveryReport,
  buildInspectionReport,
  formatDiscoveryReport,
  formatInspectionReport,
  formatRegistrationLifetimeInspect,
} from "../inspection/index.js";
import {
  resolveDiscoveryManifestContext,
  runDiscoveryAnalysis,
} from "../inspection/runDiscoveryAnalysis.js";

type GeneratedMainManifestModule = {
  iocManifest: IocGeneratedContainerManifest;
};

const formatResolvedScanDir = (e: ResolvedScanDir): string => {
  let base = e.absPath;
  if (e.scope !== undefined) {
    base = `${base} [scope=${e.scope}]`;
  }
  if (e.importPrefix !== undefined && e.importMode !== undefined) {
    return `${base} → ${e.importPrefix} (${e.importMode})`;
  }
  return base;
};

const logInspectContext = (cfgPath: string, scanDirs: ResolvedScanDir[]): void => {
  console.error(`[ioc inspect] resolved config: ${cfgPath}`);
  console.error(
    `[ioc inspect] resolved discovery scanDirs: ${scanDirs.map(formatResolvedScanDir).join("; ")}`,
  );
};

const loadGeneratedManifestModule = async (
  iocConfigPath?: string,
  searchStartDir?: string,
): Promise<GeneratedMainManifestModule> => {
  const searchStart = path.resolve(searchStartDir ?? process.cwd());
  const cfgPath = resolveIocConfigPath(searchStart, iocConfigPath);
  const config = await tryLoadIocConfig(cfgPath);
  const projectRoot = config
    ? resolveProjectRootFromIocConfigPath(cfgPath)
    : searchStart;
  const base = resolveManifestOptions({
    paths: { projectRoot },
  });
  const options = config
    ? mergeManifestOptionsWithIocConfig(base, config)
    : base;
  logInspectContext(cfgPath, options.paths.scanDirs);
  const manifestPath = path.resolve(options.paths.manifestOutPath);
  const main = (await import(pathToFileURL(manifestPath).href)) as
    GeneratedMainManifestModule;
  return main;
};

const main = async (): Promise<void> => {
  const parsed = parseIocCliArgv(process.argv);
  if (parsed.kind === "help") {
    console.log(IOC_CLI_HELP_TEXT.trimEnd());
    return;
  }

  const cli = parsed.options;
  const searchStart = path.resolve(cli.projectDir ?? process.cwd());

  if (cli.discovery) {
    const resolved = await resolveDiscoveryManifestContext({
      iocConfigPath: cli.iocConfigPath,
      searchStartDir: searchStart,
    });
    logInspectContext(resolved.cfgPath, resolved.options.paths.scanDirs);

    const analysis = await runDiscoveryAnalysis({
      reuseResolution: resolved,
    });
    const report = buildDiscoveryReport(analysis);
    console.log(formatDiscoveryReport(report));
    console.log("");
    console.log(formatRegistrationLifetimeInspect(analysis.registrationPlan));
    return;
  }

  const mainMod = await loadGeneratedManifestModule(
    cli.iocConfigPath,
    searchStart,
  );

  const report = buildInspectionReport(mainMod.iocManifest.contracts);
  console.log(formatInspectionReport(report));
};

main().catch((error: unknown) => {
  if (process.env.IOC_DEBUG === "1") {
    console.error(error);
  } else {
    console.error(error instanceof Error ? error.message : error);
  }
  process.exit(1);
});
