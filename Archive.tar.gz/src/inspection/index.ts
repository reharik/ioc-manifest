/**
 * Inspection entry: validate manifests, run discovery analysis, format printable reports.
 */
export {
  buildDiscoveryReport,
  buildInspectionReport,
  type DiscoveryExportReportRow,
  type DiscoveryReport,
  type DiscoveryReportInput,
  type InspectionContractReport,
  type InspectionReport,
} from "./reports.js";

export {
  resolveDiscoveryManifestContext,
  runDiscoveryAnalysis,
  type DiscoveryAnalysisResult,
  type DiscoveryManifestResolution,
} from "./runDiscoveryAnalysis.js";

export {
  formatDiscoveryReport,
  formatInspectionReport,
  formatRegistrationLifetimeInspect,
  type FormatDiscoveryReportOptions,
} from "./formatReports.js";

export {
  validateManifest,
  type ManifestValidationIssue,
} from "./validateManifest.js";
