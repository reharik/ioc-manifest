# ioc-manifest

**Build-time discovery and codegen for Awilix (PROXY mode).** This package generates a typed registration manifest from your TypeScript sources. It is **not** an IoC container and **does not replace Awilix** — you still create an Awilix container and call `registerIocFromManifest` so discovered factories are registered with correct keys and lifetimes.

At a glance:

- **Discovers** `build*` (configurable) factory exports under `discovery.scanDirs`
- **Infers** contracts from return types and dependency parameters
- **Emits** `ioc-manifest.ts` (data for registration) and `ioc-registry.types.ts` (typed cradle)
- **Registers** everything into Awilix via the small runtime helper in this package

---

## What this is / is not

| This package | Not this package |
| --- | --- |
| Codegen + conventions + validation | A general-purpose DI container |
| Works with **Awilix PROXY** mode and flat resolvers | Class/decorator frameworks (NestJS, Inversify, …) |
| **Production policy** in **`ioc.config` only** | Per-factory registration metadata in source files |

**Factories must stay plain exports** (typically arrow functions). **Do not** attach `lifetime`, `scope`, `name`, `accessKey`, or other registration options to factory definitions. Those belong only in **`ioc.config.ts`** (`registrations`, `discovery.scanDirs[].scope`, groups, etc.). The generator does not look for a `{ factory, lifetime }` object pattern in your codebase.

---

## Mental model

```
Factory export → inferred contract → registration plan (config + conventions)
  → generated manifest → Awilix container (your app)
```

You write small **factory functions**. The TypeScript program is analyzed at codegen time. The output manifest lists modules, registration keys, lifetimes, and defaults; the runtime applies that list to Awilix.

---

## Conventions

### Factory shape

Use a **function** (named `build…` by default) with an explicit or inferable return type. Dependencies are taken by **parameter destructuring** in PROXY mode; after registration, Awilix passes a cradle object whose properties match your generated keys.

**Good — plain export, policy in `ioc.config`:**

```ts
import type { UserRepository } from "./UserRepository.js";
import type { UserService } from "./UserService.js";
import type { IocGeneratedCradle } from "../generated/ioc-registry.types.js";

export const buildUserService = ({
  userRepository,
}: IocGeneratedCradle): UserService => {
  return {
    getUser: (id) => userRepository.findById(id),
  };
};
```

**Not documented or supported — registration data on the factory:**

```ts
// Do not do this. Lifetime, scope, and keys belong in ioc.config only.
export const buildThing = {
  lifetime: "scoped",
  factory: () => {
    /* … */
  },
};
```

Class-based constructor injection is out of scope for the intended workflow; you can use classes as *return values*, but the primary pattern is factories + PROXY cradle.

### Key derivation

For a factory `buildHttpClient` returning `MyService`:

- **Contract** → `MyService` (return type symbol name)
- **Implementation id** → `httpClient` (export name with prefix stripped, first char lowercased)
- **Default access key** → `myService` (camel-cased contract name)

Resolvers:

- `container.resolve("myService")` — default implementation for that contract (unless overridden)
- `container.resolve("httpClient")` — this implementation by registration key
- `container.resolve("myServices")` — array when multiple implementations exist and a plural collection key applies

Exact keys and lifetimes can be overridden in **`ioc.config`** (see below).

---

## `ioc.config` — single source of policy

Put **`ioc.config.ts`** at the package root or under `src/` (see path resolution below). Export **`defineIocConfig({...})`** or a plain object (validation is the same).

Only these top-level keys are allowed: `discovery`, `registrations`, `groups`. Unknown keys fail validation with `[ioc-config]`.

### `discovery`

| Field | Purpose |
| --- | --- |
| `scanDirs` | **Required.** Non-empty string, string array, or array of objects `{ path, importPrefix?, importMode?, scope? }` (see below). Paths are relative to the **package root** (parent of `src/` when config lives in `src/`), unless absolute. |
| `includes` / `excludes` | Optional glob lists for discovery (defaults exist when omitted — tighten for your repo). |
| `factoryPrefix` | Prefix for factory exports (default `build`). |
| `generatedDir` | Where `ioc-manifest.ts` and `ioc-registry.types.ts` are written (default `generated`). |
| `workspacePackageImportBases` | Optional `{ root, importBase }[]` so contract types emitted under a package root use a **public** bare specifier instead of deep relative paths. Each entry allows only `root` and `importBase`; both must be non-empty strings. |

#### Discovery roots and `scanDirs`

Each entry defines a **discovery root**: factories under that tree are discovered using the same TS program as your app. If you use **object** entries:

- **`scope`** — default Awilix lifetime (`singleton` \| `scoped` \| `transient`) for factories whose source file resolves to this root. Per-implementation `registrations[Contract][impl].lifetime` wins. If one file could match multiple roots with different `scope` values, generation fails with an actionable error.
- **`importPrefix` + `importMode`** — control how **generated imports** refer to factory modules. When `importPrefix` is set, `importMode` must be `root` (emit exactly that prefix) or `subpath` (emit `${importPrefix}/${pathFromScanRoot}`). `importPrefix` cannot be used without `importMode`. `importMode: "root"` without `importPrefix` is rejected.

Relative imports in generated files are always written so consumers depend on **supported** paths (package root, aliases you configured) — not on private paths inside `node_modules`.

### `registrations`

Override **defaults**, **lifetimes**, **Awilix registration keys** (`name`), and **contract-level** settings.

- Keys at `registrations[ContractName]` are **implementation names** from discovery (`buildX` → `x`), except the reserved **`$contract`** object for contract-level options.
- Under each implementation, only **`name`**, **`lifetime`**, **`default`** are allowed.
- Under **`$contract`**, only **`accessKey`** is allowed (non-empty string; cannot be `"$contract"`).

**`accessKey`** — cradle / default-slot property for the contract when it should differ from the camel-cased contract name (e.g. singular `database` while the type is `Knex`).

**`$contract` example:**

```ts
registrations: {
  Knex: {
    $contract: { accessKey: "database" },
    pg: { default: true, lifetime: "singleton" },
  },
},
```

### Default implementation when multiple factories share a contract

Order of precedence:

1. **`default: true`** on exactly one implementation under `registrations[Contract]` (after merges).
2. **Convention** — implementation whose registration key equals the camel-cased contract name (e.g. `myService` for `MyService`).
3. **Single implementation** — if only one exists, it becomes the default.

If more than one row is marked `default: true`, or the choice is otherwise ambiguous, generation fails with a clear error. **Defaults are configured only in `ioc.config`**, not in factory source files.

### Groups

Optional `groups` map names to `{ kind: "collection" \| "object", baseType: "SomeType" }` so multiple contracts assignable to `SomeType` appear as an array (`collection`) or object (`object`) on the cradle. Only `kind` and `baseType` are allowed per entry.

---

## Generated files

| File | Role |
| --- | --- |
| `ioc-manifest.ts` | Imports factory modules and exports `iocManifest` consumed by `registerIocFromManifest` |
| `ioc-registry.types.ts` | `IocGeneratedCradle` and related types for `container.resolve` |

Treat them as build artifacts: **do not edit by hand**. Regenerate after changing factories or config.

Imports in generated modules use types from the **`ioc-manifest`** package (`IocGeneratedContainerManifest`, etc.) — not deep imports into this repo’s `src/`.

---

## Quick start

### 1. Configure

```ts
// src/ioc.config.ts
import { defineIocConfig } from "ioc-manifest";

export default defineIocConfig({
  discovery: {
    scanDirs: "src",
    includes: ["**/*.{ts,tsx}"],
    excludes: ["**/*.test.ts", "generated/**/*"],
    factoryPrefix: "build",
    generatedDir: "generated",
  },
});
```

### 2. Factories

```ts
import type { MyService } from "./MyService.js";

export const buildHttpClient = (): MyService => {
  return { doThing: () => "hello" };
};
```

### 3. Generate

Programmatic:

```ts
import { generateManifest } from "ioc-manifest";

await generateManifest();
```

Or run your own script that calls `generateManifest({ iocConfigPath: "…" })` when needed. The repo uses `tsx` to run an internal generator script; consumers typically wire `generateManifest` into a `package.json` script.

To debug the generator CLI with full stack traces, run with **`IOC_DEBUG=1`** (otherwise only the error message is printed to stderr).

### 4. Bootstrap Awilix

```ts
import { createContainer, InjectionMode } from "awilix";
import { registerIocFromManifest } from "ioc-manifest";
import { iocManifest } from "./generated/ioc-manifest.js";
import type { IocGeneratedCradle } from "./generated/ioc-registry.types.js";

const container = createContainer<IocGeneratedCradle>({
  injectionMode: InjectionMode.PROXY,
});

registerIocFromManifest(container, iocManifest);

const svc = container.resolve("myService");
```

(Use your project’s actual `InjectionMode` import from `awilix`.)

---

## CLI: `ioc`

The `ioc` binary is included for inspecting manifests and discovery. **Help** (exit **0**):

```bash
npx ioc
npx ioc --help          # same as -h
npx ioc -h
npx ioc inspect --help
npx ioc inspect -h
```

**Inspect** (same flags as always):

```bash
npx ioc inspect
npx ioc inspect --discovery
npx ioc inspect --config ./src/ioc.config.ts --project ./packages/api
# Equivalent: ... -c ./src/ioc.config.ts
```

| Flag | Meaning |
| --- | --- |
| `--discovery` | Re-run factory discovery / registration planning; do **not** read the generated manifest. |
| `--config PATH` , `-c PATH` | Explicit `ioc.config.ts` path. |
| `--project PATH` | Directory used to resolve config (default: current directory). |

- **`ioc inspect`** — loads the **generated** `ioc-manifest.ts` from disk (same path resolution as generation), prints a contract/implementation summary.
- **`ioc inspect --discovery`** — re-runs discovery and registration planning without reading the manifest (good for “why didn’t this register?”).

Malformed CLI usage (wrong command / unknown flag) exits **1** with a short message plus a usage hint; **help** and successful **inspect** exit **0**. Manifest or environment failures from Node loaders also exit **1** unless you set **`IOC_DEBUG=1`** for full stack traces.

---

## Larger example (repositories / services / routes)

**`src/repos/buildUserRepository.ts`**

```ts
import type { UserRepository } from "./UserRepository.js";

export const buildUserRepository = (): UserRepository => ({
  findById: async () => undefined,
});
```

**`src/services/buildUserService.ts`**

```ts
import type { UserRepository } from "../repos/UserRepository.js";
import type { UserService } from "./UserService.js";
import type { IocGeneratedCradle } from "../../generated/ioc-registry.types.js";

export const buildUserService = ({
  userRepository,
}: IocGeneratedCradle): UserService => ({
  get: (id) => userRepository.findById(id),
});
```

**`ioc.config.ts`** (lifetimes and defaults here, not in the files above):

```ts
export default defineIocConfig({
  discovery: { scanDirs: "src", generatedDir: "generated" },
  registrations: {
    UserService: {
      userService: { default: true, lifetime: "scoped" },
    },
    UserRepository: {
      userRepository: { lifetime: "singleton" },
    },
  },
});
```

---

## Error handling and exit codes

- Messages for config problems are prefixed **`[ioc-config]`**.
- Messages for discovery / planning / manifest issues are prefixed **`[ioc]`**.
- CLI **`ioc`** exits **`0`** for **`-h` / `--help`** and successful **`inspect`**; exits **`1`** on invalid CLI usage or failed inspect/discovery runs.
- Runtime resolution errors (`IocResolutionError`) include dependency chains for debugging.

---

## Pitfalls and troubleshooting

- **Manifest out of date** — Regenerate after editing factories or `ioc.config`.
- **Contract not discovered** — Return type must resolve to a named type; contract symbol must be in scope (imported or declared in the same file).
- **Duplicate registration keys or implementation names** — Rename exports or use `registrations` `name` overrides so Awilix keys stay globally unique.
- **Overlapping `scanDirs` with different `scope`** — Narrow roots or set lifetimes per implementation in `registrations`.
- **`registrations` for unknown contracts** — Keys must match discovered contract type names; typos fail with a list of discovered contracts.
- **Inspect shows `lifetimeSource: factory-config`** — That label means the lifetime came from **`ioc.config`**, not from a factory file (historical identifier in inspect output).

---

## Installation

```bash
npm install ioc-manifest
```

Peer expectation: your app already uses **Awilix** (this package lists `awilix` as a dependency for types/runtime alignment).

---

## Scripts (this repo)

- **`npm run build`** — compile `src/` to `dist/`
- **`npm test`** — unit and integration tests
- **`npm run pack:dev`** — build and `npm pack` for a dry-run tarball

Consumers normally depend on the published package; only `dist/`, `bin/`, `LICENSE`, and `README.md` are intended for the registry artifact.

---

## License

MIT — see [LICENSE](./LICENSE).
